 /*@@
   @header    ParameterData.h
   @date      Fri Jan 15 14:06:43 1999
   @author    Tom Goodale
   @desc 
   
   @enddesc
   @version $Id$
 @@*/

int ProcessParameterDatabase(tFleshConfig *ConfigData);

int CCTKi_InitialiseParameters(tFleshConfig *ConfigData);


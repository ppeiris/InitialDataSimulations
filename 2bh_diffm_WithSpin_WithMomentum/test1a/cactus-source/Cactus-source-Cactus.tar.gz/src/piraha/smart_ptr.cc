#include "smart_ptr.hpp"

namespace cctki_piraha {

std::set<void*> *ptrs = 0;

}

data->data_m3 = DATA(-3);
data->data_m2 = DATA(-2);
data->data_m1 = DATA(-1);
data->data_0 = DATA(0);
data->data_p1 = DATA(1);
data->data_p2 = DATA(2);
data->data_p3 = DATA(3);

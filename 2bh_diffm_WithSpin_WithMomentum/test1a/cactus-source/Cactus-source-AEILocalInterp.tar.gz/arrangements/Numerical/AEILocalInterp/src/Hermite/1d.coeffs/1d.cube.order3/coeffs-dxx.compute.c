      coeffs_dxx->coeff_m2 = RATIONAL(-1.0,3.0)+RATIONAL(1.0,2.0)*x;
      coeffs_dxx->coeff_m1 = RATIONAL(-7.0,2.0)*x+RATIONAL(5.0,2.0);
      coeffs_dxx->coeff_0 = RATIONAL(-14.0,3.0)+RATIONAL(8.0,1.0)*x;
      coeffs_dxx->coeff_p1 = RATIONAL(10.0,3.0)+RATIONAL(-8.0,1.0)*x;
      coeffs_dxx->coeff_p2 = RATIONAL(7.0,2.0)*x+RATIONAL(-1.0,1.0);
      coeffs_dxx->coeff_p3 = RATIONAL(1.0,6.0)+RATIONAL(-1.0,2.0)*x;

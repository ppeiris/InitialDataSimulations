      coeffs_dx->coeff_0 = RATIONAL(-1.0,1.0);
      coeffs_dx->coeff_p1 = RATIONAL(1.0,1.0);

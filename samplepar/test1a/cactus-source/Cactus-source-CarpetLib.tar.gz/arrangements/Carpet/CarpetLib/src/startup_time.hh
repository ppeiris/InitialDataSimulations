namespace CarpetLib {
  
  void
  output_startup_time ();
  
} // namespace CarpetLib

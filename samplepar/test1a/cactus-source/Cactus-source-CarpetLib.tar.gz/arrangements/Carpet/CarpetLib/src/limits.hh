#include <cctk.h>

namespace CarpetLib {
  
  void
  set_system_limits ();
  
} // namespace CarpetLib

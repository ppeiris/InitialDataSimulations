#ifndef SENDDATA_HH
#define SENDDATA_HH

#include <list>
#include <string>

namespace Formaline {

using namespace std;

int SendData(string hostname, int port, string data);

} // namespace Formaline

#endif // #ifndef SENDDATA_HH

/*@@
  @header   LIEG_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef LIEG_GUTS

#include "DB_undefine.h"
#include "DG_undefine.h"



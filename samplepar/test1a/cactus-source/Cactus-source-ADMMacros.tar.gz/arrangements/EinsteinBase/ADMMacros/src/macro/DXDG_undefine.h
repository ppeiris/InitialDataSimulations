/*@@
  @header   DXDG_undefine.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DXDG_GUTS

#include "DXDCG_undefine.h"


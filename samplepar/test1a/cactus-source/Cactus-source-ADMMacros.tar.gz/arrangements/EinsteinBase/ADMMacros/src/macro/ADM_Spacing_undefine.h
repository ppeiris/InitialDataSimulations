/*@@
  @header   ADM_Spacing_undefine.h
  @date     December 2004
  @author   Erik Schnetter
  @desc
            Undefine various spacing dependent scalars.
  @enddesc
@@*/

#undef ADM_SPACING_H

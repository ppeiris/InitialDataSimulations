/*@@
  @header   DZDG_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DZDK_GUTS



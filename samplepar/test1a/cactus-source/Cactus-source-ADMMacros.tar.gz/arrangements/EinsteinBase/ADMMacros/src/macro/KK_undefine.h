/*@@
  @header   KK_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef KK_GUTS

#include "UPPERMET_undefine.h"

  

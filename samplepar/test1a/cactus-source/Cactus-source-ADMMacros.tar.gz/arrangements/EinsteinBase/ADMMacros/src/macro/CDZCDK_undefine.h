/*@@
  @header   CDZCDK_undefine.h
  @date     Aug 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef CDZCDK_GUTS

#include "DZDK_undefine.h"
#include "CHR2_undefine.h"

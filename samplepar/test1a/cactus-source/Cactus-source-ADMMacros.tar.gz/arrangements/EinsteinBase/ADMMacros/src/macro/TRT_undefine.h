/*@@
  @header   TRT_undefine.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef TRT_GUTS

#include "UPPERMET_undefine.h"


  

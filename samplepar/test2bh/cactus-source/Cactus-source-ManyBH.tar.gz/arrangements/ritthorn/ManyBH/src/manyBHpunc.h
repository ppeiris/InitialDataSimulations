class Tenseur ;
class Tenseur_sym ;
class Map_et ;

class BHpunc {
  
 protected:

  // Mapping
  Map_et& mp ;
  
  // u
  Tenseur u ;
  Tenseur u1 ;
  Tenseur u2 ;
  Tenseur alpha ;
  Tenseur beta ;

  Tenseur rhsval ;

  // Sources at the previous step
  Tenseur so_jm1_u ;

 public:
  // Constructors
  BHpunc (Map_et& mpi) : 
    mp(mpi),u(mpi),u1(mpi),u2(mpi),alpha(mpi),beta(mpi),rhsval(mpi),
    so_jm1_u(mpi) {} ;
    
    // Destructor
    ~BHpunc() {};
    
    int twostars;
    double xbh[3];
    double pbh[3];
    double sbh[3];
    double mbh;
    
 public:
    
    void sauve (FILE*) const ;
    
    void operator= (const BHpunc&) ;
    
    const Map_et& get_mp() const {return mp ;};
    
 public:
    
    Tenseur& set_alpha() {return alpha;} ;
    Tenseur& set_beta() {return beta;} ;
    Tenseur& set_u() {return u;} ;
    Tenseur& set_u1() {return u1;} ;
    Tenseur& set_u2() {return u2;} ;
    Tenseur& set_rhsval() {return rhsval;} ;
    
    void solve_config (double precis, int ite_max,
		       double relax, int ite_poisson_max) ;
    
    void solve_equation (double, int) ;
    
};

class Many_BH {
  
 public:
  
  int nbh;
  const double* xbhvec;
  
 protected:
  
  Map_et** maparray;
  BHpunc** bhpuncarray ;
  
 public:
  // Constructors
  Many_BH (const int& n, Map_et** mparray, BHpunc** bhparray, const double* xvec){
    nbh = n;
    maparray=mparray;
    bhpuncarray=bhparray;
    xbhvec = xvec;
  };
  
  // Destructor
  ~Many_BH() {} ;
  
 public:
  
  void sauve (FILE*) const ;
  
  void operator= (const Many_BH&) ;
  
 public:
  
  BHpunc* set_bh(int n) {return bhpuncarray[n];} ;
  
  void calc_us() ;
  
  void solve_config (double precis, int ite_max,
		     double relax, int ite_poisson_max) ;
  
  void export_points(int nbp, double* xi, double* yi, double* zi,
		     double* g_xx, double* g_xy, double* g_xz,
		     double* g_yy, double* g_yz, double* g_zz,
		     double* k_xx, double* k_xy, double* k_xz,
		     double* k_yy, double* k_yz, double* k_zz);
  
};

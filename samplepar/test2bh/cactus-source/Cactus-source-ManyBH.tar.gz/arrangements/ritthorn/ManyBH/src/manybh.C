// headers C++
#include <iostream>
#include <fstream>

// headers C
#include <stdlib.h>
#include <math.h>
#include <string.h>

// headers Lorene
#include "nbr_spx.h"
#include "tbl.h"
#include "mtbl.h"
#include "map.h"
#include "binaire.h"
#include "param.h"
#include "eos.h"
#include "graphique.h"
#include "utilitaires.h"
#include "unites.h"

// Header perso
#include "manyBHpunc.h"

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"

//extern "C" int ManyBH_spectralinit(CCTK_ARGUMENTS);
//extern "C" int ManyBH_initialdata(CCTK_ARGUMENTS);
//extern "C" int ManyBH_cleanup(CCTK_ARGUMENTS);

static Mg3d *grid3d = NULL;
static Many_BH *manybh = NULL;
static BHpunc **bhpuncarray = NULL;
static Map_et **maparray = NULL;

using namespace Unites;

// If this is 0, we get the old split of the Kij Kij cross terms
// If it is 1, we get the new version with (m/r)^2 factors

void ManyBH_spectralinit(CCTK_ARGUMENTS) {

  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  assert(manybh==NULL);

  // We use nz nested radial domains, each of the same size

  int i,j,k,l,ii,jj;
  double ij;

  cout<<"manbh: Lorene grids:"<<nz<<" "<<np<<" "<<nt<<" "<<nr<<endl;

  // Construction of the field :
  int typep = NONSYM ;
  int typet;
  
 // const double rsurf=0.5;
  // This sets up the radial extent of each domain, currently in a geometric progression
  // We begin at a radius of rsurf for the outer radius of the innermost spherical domain
  
  double *r_lim = new double[nz+1] ;
  r_lim[0] = 0 ;
  for (i=1 ; i<nz ; i++) {
    r_lim[i]=rsurf*pow(1.8,i-1);
    
    cout<<"manybh:  rlim:"<<i<<" "<<r_lim[i];
    //r_lim[i]=rsurf*pow(2.0,i-1);
  }
  cout<<endl;
  
  // Our domains extend to compactified spatial infinity
  r_lim[nz]=__infinity;
  
  
  
  //--------------------BH Pars-------------------- 
  
 int symcheck=0;
  for (ii=0; ii<nbh; ii++) {
    if(pbh[3*ii+2]!=0||sbh[3*ii]!=0||sbh[3*ii+1]!=0)symcheck=1;
  }

  //Symmetry check!
  if(symcheck==0) {
    //We have vertical symmetry!
    // This is tuned to only cover the upper half plane, assuming vertical symmetry 
    cout<<"manybh: Vertical symmetry!"<<endl;
    typet = SYM ;
  } else {
    //No symmetry, grid covers all of space
    cout<<"manybh: No vertical symmetry!"<<endl;
    typet = NONSYM ;
  }
  
  //  As a general rule, we don't want black holes in the outermost domain, nor anywhere near it!
  for(ii=0; ii<nbh; ii++) {
    for(i=0; i<nbh; i++) {
      if(i!=ii) {
	double xd=xbh[3*ii]-xbh[3*i];
	double yd=xbh[3*ii+1]-xbh[3*i+1];
	double zd=xbh[3*ii+2]-xbh[3*i+2];
	double rd=sqrt(xd*xd+yd*yd+zd*zd);
	if(rd > r_lim[nz-1]) {
	  cout<<"Sep0 is too close to the outermost domain!!!"<<endl;
	  cout<<"sep0="<<rd<<" "<<ii<<" "<<i<<" and r_lim="<<r_lim[nz-1]<<endl;
	  exit(1);
	}
      }
    }
  }
  
  //  CCTK_REAL *xbhv = new CCTK_REAL [3*nbh];
  //  for (i=0; i<3*nbh; i++)xbhv[i]=xbh[i];

  // This line just establishes a 3-d radial/angular grid with the parameters given above
  grid3d = new Mg3d(nz,nr,nt,np,typet,typep,true) ;

  //NEW PART!!!
  maparray = new Map_et*[nbh];
  bhpuncarray = new BHpunc*[nbh];
 
  //To assign an initial guess, we want to put in the form from Laguna
  //We do this by figuring out the coords of the relevant points and evaluating his terms there

  //The map is related to the 3-d grid, but sets up a structure with all of the NZ nested domains
  //We extend to spatial infinity by using a coordinate transformation in the outermost domain

  for (ii=0; ii<nbh; ii++) {
    maparray[ii] = new Map_et(*grid3d,r_lim);
    maparray[ii]->set_rot_phi(0);
    bhpuncarray[ii] = new BHpunc(*maparray[ii]);
  }

  manybh = new Many_BH(nbh,maparray,bhpuncarray,xbh);

  int ibh,jbh;

  for (ibh=0; ibh<nbh; ibh++) {

    // Star n :
    //Mtbl Xabs1 (mp1.xa) ;
    Mtbl Xabs (maparray[ibh]->xa) ;
    Mtbl Yabs (maparray[ibh]->ya) ;
    Mtbl Zabs (maparray[ibh]->za) ;

//   // Alpha and beta are terms in the RHS of the equatin for psi taken from Brandt & Brugmann
    Tenseur alp1 (*maparray[ibh]) ;
    alp1.allocate_all() ;
    Tenseur bet1 (*maparray[ibh]) ;
    bet1.allocate_all() ;
    Tenseur uterm1 (*maparray[ibh]) ;
    uterm1.allocate_all() ;

    //   Tenseur alp2 (mp2) ;
    //   alp2.allocate_all() ;
    //   Tenseur bet2 (mp2) ;
    //   bet2.allocate_all() ;
    //   Tenseur uterm2 (mp2) ;
    //   uterm2.allocate_all() ;
    
    for (l=0 ; l<nz ; l++)
      for (k=0 ; k<np ; k++)
	for (j=0 ; j<nt ; j++)
	  for (i=0 ; i<nr ; i++) {

	    double rom1,rom2,distfact;

	    double alpvaldenom = 0.;

	    //Self term
	    double xx = Xabs(l,k,j,i) ;
	    double yy = Yabs(l,k,j,i) ;
	    double zz = Zabs(l,k,j,i) ;

	    // Solve for Kxx1 around star 1
	    double r1=pow(xx*xx+yy*yy+zz*zz,0.5);
	    double mbh1=mbh[ibh];
	    rom1=r1/mbh1;
	    if(r1!=0)alpvaldenom = 0.5*mbh1/r1;
  
	    double n1[3];
	    n1[0]=xx/r1;
	    n1[1]=yy/r1;
	    n1[2]=zz/r1;
	    double pn1=0.;
	    for (ii=0; ii<3; ii++)pn1+=pbh[3*ibh+ii]*n1[ii];

	    double k1[9];
	    
	    ij=0.;
	    for (ii=0; ii<3; ii++) {
	      for (jj=0; jj<3; jj++) {
		int ind=3*ii+jj;
		if(ii==jj){
		  ij=1.;
		} else {
		  ij=0.;
		}
		k1[ind]=1.5*(pbh[3*ibh+ii]*n1[jj]+pbh[3*ibh+jj]*n1[ii]-
			     (ij-n1[ii]*n1[jj])*pn1)/r1/r1;

		if(sbh[3*ibh]!=0.||sbh[3*ibh+1]!=0.||sbh[3*ibh+2]!=0.) {
		  int i1 = (ii==2) ? 0 : ii+1;
		  int i2 = (ii==0) ? 2 : ii-1;
		  int j1 = (jj==2) ? 0 : jj+1;
		  int j2 = (jj==0) ? 2 : jj-1;
		  k1[ind]+=3.0*((sbh[3*ibh+i1]*n1[i2]-sbh[3*ibh+i2]*n1[i1])*n1[jj]+
				(sbh[3*ibh+j1]*n1[j2]-sbh[3*ibh+j2]*n1[j1])*n1[ii])/pow(r1,3.0);
		}

	      }
	    }
	    
	    
	    // Take care of the cross terms too!

	    double k12[9];
	    for (ii=0; ii<9; ii++)k12[ii]=0.;
	    
	    for (jbh=0; jbh<nbh; jbh++) {
	      if(ibh!=jbh) {
		double x12[3];
		for (ii=0; ii<3; ii++)x12[ii]=xbh[3*ibh+ii]-xbh[3*jbh+ii];
		
		//solve for Kxx2 around star 1
		double r12=pow(pow(xx+x12[0],2.)+pow(yy+x12[1],2.)+pow(zz+x12[2],2.),0.5);

		if(r12!=0)alpvaldenom += 0.5*mbh[jbh]/r12;

		double n12[3];
		n12[0]=(xx+x12[0])/r12;
		n12[1]=(yy+x12[1])/r12;
		n12[2]=(zz+x12[2])/r12;
		double pn12=0.;
		for (ii=0; ii<3; ii++)pn12+=pbh[3*jbh+ii]*n12[ii];
		
		// 	  //	  cout<<"ijkl:"<<i<<" "<<j<<" "<<k<<" "<<l<<" "<<r1<<" "<<r12<<" "<<yy+x12[1]<<" "<<n1[0]<<" "<<n1[1]<<" "<<n1[2]<<" "<<pn1/mbh1/mbh1<<" "<<n12[0]<<" "<<n12[1]<<" "<<n12[2]<<" "<<pn12/mbh2/mbh2<<endl;
		
		ij=0.;
		for (ii=0; ii<3; ii++) {
		  for (jj=0; jj<3; jj++) {
		    int ind=3*ii+jj;
		    if(ii==jj){
		      ij=1.;
		    } else {
		      ij=0.;
		    }
		    double kp=1.5*(pbh[3*jbh+ii]*n12[jj]+pbh[3*jbh+jj]*n12[ii]-
				   (ij-n12[ii]*n12[jj])*pn12)/r12/r12;
		    
		    
		    double ks=0;
		    if(sbh[3*jbh]!=0.||sbh[3*jbh+1]!=0.||sbh[3*jbh+2]!=0.) {
		      int i1 = (ii==2) ? 0 : ii+1;
		      int i2 = (ii==0) ? 2 : ii-1;
		      int j1 = (jj==2) ? 0 : jj+1;
		      int j2 = (jj==0) ? 2 : jj-1;
		      ks=3.0*((sbh[3*jbh+i1]*n12[i2]-sbh[3*jbh+i2]*n12[i1])*n12[jj]+
			      (sbh[3*jbh+j1]*n12[j2]-sbh[3*jbh+j2]*n12[j1])*n12[ii])/pow(r12,3.0);
		    }
		    
		    rom2 = r12 / mbh[jbh];
		    
		    distfact = 2.0*rom2*rom2/(rom1*rom1+rom2*rom2); 
		    
		    k12[ind] += distfact*(kp+ks);
		  }
		}
	      }
	    }
	  
 	  
	  
	    // This is where we give an initial guess u1, taken from Laguna
	    //We will calculate the u cross-terms accurately,
	    //since this needs to be done after each solver iteration

	    //Star 1	  
	    double rh1=r1/mbh1;
	    double pbh1sq=pow(pbh[3*ibh],2.)+pow(pbh[3*ibh+1],2.)+pow(pbh[3*ibh+2],2.)+1.0e-10;
	    double uf=pbh1sq/mbh1/mbh1/8.0/pow(1.0+2.0*rh1,5);
	    double u0=1.0+10.0*rh1+40.0*rh1*rh1+80.0*pow(rh1,3)+80.0*pow(rh1,4);
	    double p2,u2;
	    if(r1>0) {
	      p2=1.5*pn1*pn1/pbh1sq-0.5;
	      u2=p2/5.0/pow(rh1,3)*(42.0*rh1+378.0*rh1*rh1+1316.0*pow(rh1,3)+
 				     2156.0*pow(rh1,4)+1536.0*pow(rh1,5)+240.0*pow(rh1,6)-
 				     21.0*pow(1.0+2.0*rh1,5)*log(1.0+2.0*rh1));
	    } else {
	      p2=0.;
	      u2=0.;
	    }
	    double uval1=uf*(u0+u2);
	    
	    // 	  //	  cout<<"ijkl:"<<i<<" "<<j<<" "<<k<<" "<<l<<" "<<rh1<<" "<<uf<<" "<<u0<<" "<<u2<<" "<<p2<<" "<<uval1<<endl;
	    
	    
	    // Handle the star
	    double alpval1;
	    
	    double kk1=0.;
	    for (ii=0; ii<9; ii++) {
	      kk1+=k1[ii]*(k1[ii]+k12[ii]);
	    }	    
	  
	    alpval1=1.0/alpvaldenom;
	  
	    double alp17=pow(alpval1,7);
	    double betval1=0.125*alp17*kk1;
	  
	    if((l==nz-1) && (i==nr-1)){
	      alpval1=0.;
	      betval1=0.;
	      uval1=0.;
	    }
	    if(r1==0) {
	      alpval1=0.;
	      betval1=0.;
	      kk1=0.;
	    
	    }

	    alp1.set().set(l,k,j,i) = alpval1 ;

	    bet1.set().set(l,k,j,i) = betval1 ;
	    uterm1.set().set(l,k,j,i) = uval1 ;
	  }
    
    alp1.set_std_base() ;
    bet1.set_std_base() ;
    uterm1.set_std_base() ;
    
    manybh->set_bh(ibh)->set_alpha() = alp1;
    manybh->set_bh(ibh)->set_beta() = bet1;
    manybh->set_bh(ibh)->set_u1() = uterm1;
    
    manybh->set_bh(ibh)->mbh=mbh[ibh];
    
    for(ii=0; ii<3; ii++) {
      manybh->set_bh(ibh)->pbh[ii]=pbh[3*ibh+ii];
      manybh->set_bh(ibh)->sbh[ii]=sbh[3*ibh+ii];
    }
    
  }

  cout<<"manybh: About to calc us!"<<endl;

  manybh->calc_us();

  // Solve the fields

  manybh->solve_config(precis,ite_max,relax,ite_poisson_max) ;

  delete [] r_lim;

  cout<<"Manybh: exist? "<<&manybh<<" "<<&grid3d<<endl;
  for (i=0; i<nbh; i++) cout<<"BH :"<<i<<" "<<&maparray[i]<<" "<<&bhpuncarray[i]<<endl;

  cout<<"manybh: Leaving spectralinit!"<<endl;

  return;
}

void ManyBH_initialdata(CCTK_ARGUMENTS) {

  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;

  assert(manybh);

  cout<<"manybh: Beginning initial_data!"<<endl;


  int nxx=cctk_lsh[0];
  int nyy=cctk_lsh[1];
  int nzz=cctk_lsh[2];
  int nbp=nxx*nyy*nzz;

  cout<<"manybh: grid:"<<nxx<<" "<<nyy<<" "<<nzz<<" "<<nbp<<endl;

  double* xi=new double[nbp];
  double* yi=new double[nbp];
  double* zi=new double[nbp];

  for (int k=0; k<cctk_lsh[2]; k++) {
    for (int j=0; j<cctk_lsh[1]; j++) {
      for (int i=0; i<cctk_lsh[0]; i++) {
	const int ind=CCTK_GFINDEX3D(cctkGH,i,j,k);
	xi[ind] = x[ind];
	yi[ind] = y[ind];
	zi[ind] = z[ind];
	
      }
    }
  }

  cout<<"manybh: point 5:"<<xi[5]<<" "<<yi[5]<<" "<<zi[5]<<endl;

  double* g_xx = gxx;
  double* g_xy = gxy;
  double* g_xz = gxz;
  double* g_yy = gyy;
  double* g_yz = gyz;
  double* g_zz = gzz;

  double* k_xx = kxx;
  double* k_xy = kxy;
  double* k_xz = kxz;
  double* k_yy = kyy;
  double* k_yz = kyz;
  double* k_zz = kzz;

  cout<<"Manybh: exist? "<<&manybh<<" "<<&grid3d<<endl;
  
  manybh->export_points(nbp,xi,yi,zi,g_xx,g_xy,g_xz,g_yy,g_yz,g_zz,
			k_xx,k_xy,k_xz,k_yy,k_yz,k_zz);

  delete [] xi;
  delete [] yi;
  delete [] zi;

  return;

}

void ManyBH_cleanup(CCTK_ARGUMENTS) {

  DECLARE_CCTK_ARGUMENTS;
  DECLARE_CCTK_PARAMETERS;
  
  if(manybh) {
    delete manybh;
    manybh=NULL;
  }
  if(grid3d) {
    delete grid3d;
    grid3d=NULL;
  }

  return;
}

///////  Additional routines

void Many_BH::calc_us() {
  
  int ibh,jbh;
  for(ibh=0; ibh<nbh; ibh++) {
    
    bhpuncarray[ibh]->set_u2().allocate_all();
    bhpuncarray[ibh]->set_u().allocate_all();
    
    bhpuncarray[ibh]->set_rhsval().allocate_all();
    
    Mtbl Xabs1 (maparray[ibh]->xa) ;
    Mtbl Yabs1 (maparray[ibh]->ya) ;
    Mtbl Zabs1 (maparray[ibh]->za) ;
    //   Mtbl Xabs2 (mp2.xa) ;
    //   Mtbl Yabs2 (mp2.ya) ;
    //   Mtbl Zabs2 (mp2.za) ;
    
    int nz1 = maparray[ibh]->get_mg()->get_nzone() ;
    for (int l=0 ; l<nz1 ; l++) {
      int np = maparray[ibh]->get_mg()->get_np(l) ;
      int nt = maparray[ibh]->get_mg()->get_nt(l) ;
      int nr = maparray[ibh]->get_mg()->get_nr(l) ;
      for (int k=0 ; k<np ; k++)
      for (int j=0 ; j<nt ; j++)
        for (int i=0 ; i<nr ; i++) {
	  if((l!=nz1-1) || (i!=nr-1)) {
	    double xx=Xabs1(l,k,j,i);
	    double yy=Yabs1(l,k,j,i);
	    double zz=Zabs1(l,k,j,i);

	    //self
 	    double u1val=bhpuncarray[ibh]->set_u1().set().set(l,k,j,i);
	    
	    //sum over others - need r2,t2,p2!!!
	    double u2val=0.;
	    for (jbh=0; jbh<nbh; jbh++) {
	      if(ibh!=jbh) {
		double xd=xx+xbhvec[3*ibh]-xbhvec[3*jbh];
		double yd=yy+xbhvec[3*ibh+1]-xbhvec[3*jbh+1];
		double zd=zz+xbhvec[3*ibh+2]-xbhvec[3*jbh+2];
		double r2,t2,p2;
		maparray[jbh]->convert_absolute(xd,yd,zd,r2,t2,p2) ;
		u2val+=bhpuncarray[jbh]->set_u1().set().val_point(r2,t2,p2);
	      }
	    }
	    bhpuncarray[ibh]->set_u2().set().set(l,k,j,i) = u2val;
	    bhpuncarray[ibh]->set_u().set().set(l,k,j,i) = 1.0+u1val+u2val;
	    
	    double alpval = bhpuncarray[ibh]->set_alpha().set().set(l,k,j,i);
	    double betval = bhpuncarray[ibh]->set_beta().set().set(l,k,j,i);
 	    bhpuncarray[ibh]->set_rhsval().set().set(l,k,j,i) = -1.0*betval*pow(1.0+alpval*(1.0+u1val+u2val),-7);

 	    //	    if(i==j&&j==k&&k==l)cout << u1val<<" "<<u2val<<endl;
 	  } else {
 	    bhpuncarray[ibh]->set_u2().set().set(l,k,j,i) = 0.;
 	    bhpuncarray[ibh]->set_u().set().set(l,k,j,i) = 1.;
 	  }
 	}	    
    }
  
    
    bhpuncarray[ibh]->set_u2().set_std_base();
    bhpuncarray[ibh]->set_u().set_std_base();
    
    bhpuncarray[ibh]->set_rhsval().set_std_base();
    
    
  }
}


void Many_BH::solve_config (double precis, int ite_max, 
			    double relax, int ite_poisson_max) {
  
  int ibh;
  int looping = 1 ;
  int count = 0 ;
  double err=0.;
  
  while (looping == 1) {
    err=0.;
    for(ibh=0; ibh<nbh; ibh++) {
      Cmp u1_old (bhpuncarray[ibh]->set_u1().set()) ;
      
      bhpuncarray[ibh]->solve_equation (relax, ite_poisson_max) ;
      
      double err1 = max(diffrelmax(u1_old,bhpuncarray[ibh]->set_u1().set())) ;
      err = max(err1,err);
    
    }  
    cout << "STEP " << count << " ; DIFF : " << err << endl ;
    
    count ++ ;
    if ((err < precis) || (count > ite_max))looping = -1 ;
    
    calc_us();
    
  }
}

void BHpunc::solve_equation (double relax, int itemax) {
  so_jm1_u.allocate_all() ;
  so_jm1_u.set_etat_qcq() ;
  so_jm1_u.set().set_etat_zero() ;

  Cmp rhsterm
    (-1.0*beta()*pow((1.0+alpha()*u()),-7));
  rhsterm.std_base_scal();
  rhsterm.set_dzpuis(0);
  rhsterm.inc_dzpuis();
  rhsterm.inc_dzpuis();
  rhsterm.inc_dzpuis();

  //  for (int ii=0; ii<7; ii++) {
  //    cout << rhsterm.set(ii,ii,ii,ii)<<" "<<alpha.set().set(ii,ii,ii,ii)<<" "<<beta.set().set(ii,ii,ii,ii)<<" "<<u1.set().set(ii,ii,ii,ii)<<" "<<u.set().set(ii,ii,ii,ii)<<endl;
  //  }

// Parameters for the Poisson solver
  double precis_poisson = 1e-16 ;
  int niter;

  Param par_poisson ;
  par_poisson.add_int(itemax,  0) ;
  par_poisson.add_double(relax,  0) ;
  par_poisson.add_double(precis_poisson, 1) ;
  par_poisson.add_int_mod(niter, 0) ;
  par_poisson.add_cmp_mod(so_jm1_u.set()) ;
  
  rhsterm.poisson(par_poisson, u1.set()) ;

  Cmp rhscheck (u1().laplacien());

}

void Many_BH::export_points(int nbp, double* xi, double* yi, double* zi,
			    double* g_xx, double* g_xy, double* g_xz,
			    double* g_yy, double* g_yz, double* g_zz,
			    double* k_xx, double* k_xy, double* k_xz,
			    double* k_yy, double* k_yz, double* k_zz) {
  int i,ibh;

  cout<<"manybh: export 5:"<<xi[5]<<" "<<yi[5]<<" "<<zi[5]<<endl;

  //  for (i=0; i<nbh; i++) {
  //    cout<<"manybh export: "<<&bhpuncarray[i]<<endl;
  //    cout<<"BH :"<<i<<" "<<bhpuncarray[i]->mbh<<" "<<xbhvec[3*i+1]<<" "<<bhpuncarray[i]->pbh[0]<<" "<<
  //      bhpuncarray[i]->sbh[0]<<endl;
  //  }

  for (i=0; i<nbp; i++) {
    double xx=xi[i];
    double yy=yi[i];
    double zz=zi[i];

    double uptsum=0.;
    double psisum=0.;

    double kxxpt=0.;
    double kyypt=0.;
    double kzzpt=0.;
    double kxypt=0.;
    double kxzpt=0.;
    double kyzpt=0.;

    for (ibh=0; ibh<nbh; ibh++) {
      double xxi=xx-xbhvec[3*ibh];
      double yyi=yy-xbhvec[3*ibh+1];
      double zzi=zz-xbhvec[3*ibh+2];
      double ri=sqrt(xxi*xxi+yyi*yyi+zzi*zzi);

      double xn=xxi/ri;
      double yn=yyi/ri;
      double zn=zzi/ri;

      double px=bhpuncarray[ibh]->pbh[0];
      double py=bhpuncarray[ibh]->pbh[1];
      double pz=bhpuncarray[ibh]->pbh[2];
      double sx=bhpuncarray[ibh]->sbh[0];
      double sy=bhpuncarray[ibh]->sbh[1];
      double sz=bhpuncarray[ibh]->sbh[2];
      double pdotn = px*xn+py*yn+pz*zn;
      double snx = sy*zn-sz*yn;
      double sny = sz*xn-sx*zn;
      double snz = sx*yn-sy*xn;

      double r1,t1,p1;
      //      cout<<"ibh,i:"<<ibh<<" "<<i<<"  "<<xxi<<" "<<yyi<<" "<<zzi<<endl;
      maparray[ibh]->convert_absolute(xxi,yyi,zzi,r1,t1,p1) ;
      //     cout<<"ibh,i:"<<ibh<<" "<<i<<"  "<<r1<<" "<<t1<<" "<<p1<<endl;

      uptsum += bhpuncarray[ibh]->set_u1().set().val_point(r1,t1,p1);
      psisum += 0.5*(bhpuncarray[ibh]->mbh)/ri;

      cout<<"ibh,i:"<<ibh<<" "<<i<<" upt: "<<uptsum<<" psi:"<<psisum<<endl;

      //momentum terms
      kxxpt += 3.0/2.0/ri/ri * (2.0*px*xn-(1.0-xn*xn)*pdotn);
      kyypt += 3.0/2.0/ri/ri * (2.0*py*yn-(1.0-yn*yn)*pdotn);
      kzzpt += 3.0/2.0/ri/ri * (2.0*pz*zn-(1.0-zn*zn)*pdotn);
      kxypt += 3.0/2.0/ri/ri * (px*yn+py*xn+xn*yn*pdotn);
      kxzpt += 3.0/2.0/ri/ri * (px*zn+pz*xn+xn*zn*pdotn);
      kyzpt += 3.0/2.0/ri/ri * (py*zn+pz*yn+yn*zn*pdotn);

      //spin terms
      kxxpt += 3.0/ri/ri/ri * (2.0*snx*xn);
      kyypt += 3.0/ri/ri/ri * (2.0*sny*yn);
      kzzpt += 3.0/ri/ri/ri * (2.0*snz*zn);
      kxypt += 3.0/ri/ri/ri * (snx*yn+sny*xn);
      kxzpt += 3.0/ri/ri/ri * (snx*zn+snz*xn);
      kyzpt += 3.0/ri/ri/ri * (sny*zn+snz*yn);
    }
    
    double psiv=1.0+psisum+uptsum;

    g_xx[i]=pow(psiv,4.0);
    g_yy[i]=pow(psiv,4.0);
    g_zz[i]=pow(psiv,4.0);
    g_xy[i]=0.;
    g_xz[i]=0.;
    g_yz[i]=0.;
    
    k_xx[i]=kxxpt/psiv/psiv;
    k_yy[i]=kyypt/psiv/psiv;
    k_zz[i]=kzzpt/psiv/psiv;
    k_xy[i]=kxypt/psiv/psiv;
    k_xz[i]=kxzpt/psiv/psiv;
    k_yz[i]=kyzpt/psiv/psiv;
  }

  
    
}
